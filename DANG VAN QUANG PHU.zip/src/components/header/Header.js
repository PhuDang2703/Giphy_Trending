import { Select } from 'antd';
import Search from '../search/Search';
import gif from '../../assets/gif.jpg'
import './Header.css'

const Header = () => {

  return (
    <>
      <div id="header" className="jqLLEk">
        <a itemProp="url" href="/" className="gixhfl">
          <span>
            <img src={gif} alt='gif' />
          </span>
        </a>
        {/* Menu */}
        <div className='fhtzeJ'>
          <ul className="dehIOH" style={{ backgroundPositionX: 98 }}>
            <li className="bPuqoM"><a href="https://giphy.com/reactions" className="MenuLink-sc-1ftqwtj HrelI">Reactions</a></li>

            <li className="bPuqoM"><a href="https://giphy.com/entertainment" className="MenuLink-sc-1ftqwtj HrelI">Entertainment</a></li>

            <li className="bPuqoM"><a href="https://giphy.com/sports" className="MenuLink-sc-1ftqwtj HrelI">Sports</a></li>

            <li className="bPuqoM"><a href="https://giphy.com/stickers" className="MenuLink-sc-1ftqwtj HrelI">Stickers</a></li>

            <li className="bPuqoM"><a href="https://giphy.com/artists" className="MenuLink-sc-1ftqwtj HrelI">Artists</a></li>

          </ul>
        </div>

        {/* Button */}
        <div className="bbZlrs">
          <a rel="nofollow" href="https://giphy.com/upload" className="Anchor-sc-9rqtre WmaAx" style={{ backgroundPositionX: '-138.667px' }}><span>Upload</span>
          </a>
          <a rel="nofollow" href="https://giphy.com/create/gifmaker" className="Anchor-sc-9rqtre WmaAx" style={{ backgroundPositionX: '-138.667px' }}><span>Create</span>
          </a>
        </div>

        {/* Select */}
        <div className="xDEJS">
          <div className="UserContainer-sc-1b40650 cIQQEG">
            <img src="https://media.giphy.com/avatars/default2/80h.gif" className="Img-sc-59jak1 bpaynG" alt='select'/>
            <div className="Username-sc-xgchsp fCvVdJ">
              <select className='select'>
                <option className='option'>Collections</option>
                <option>Favorites</option>
                <option>Settings</option>
                <option>Log out</option>
              </select>
            </div>
          </div>
        </div>

        {/* Privacy */}
        <div className="fYxfCZ">
          <a href="https://support.giphy.com/hc/en-us/articles/360032872931" className="hMpAbK">Privacy</a>
          <a href="https://support.giphy.com/hc/en-us/articles/360020027752-GIPHY-Terms-of-Service" className="hMpAbK">Terms</a>
        </div>
      </div>

      <Search />
    </>
  )
}

export default Header

