import { Alert, Space, Spin } from 'antd';
import styles from './Loader.module.scss'

const Loader = () => (
  <div className={styles.wrapper}>
    <div className={styles.loader}>
  <Space
    direction="vertical"
    style={{
      width: '100%',
    }}
  >
    <Space>
      <Spin size="large">
        <div className="content" />
      </Spin>
    </Space>
  </Space>
  </div>
  </div>
);
export default Loader;