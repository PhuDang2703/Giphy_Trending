import './GifItem.css'

const GifItem = ({id, gif}) => {
    return (
        <div className='GifItem'>
            <a href={`/gif-details/${id}`}>
                <picture>
                    <img className='giphy-gif-img giphy-img-loaded' src={gif.images.fixed_width.url} alt={gif.title} />
                </picture>
            </a>
        </div>
    )
}

export default GifItem