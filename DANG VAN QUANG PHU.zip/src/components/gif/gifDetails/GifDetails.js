import { useSelector } from 'react-redux'
import './GifDetails.css'
import { selectGifDetail } from '../../../redux/slice/gifSlice'

const GifDetails = () => {
  const gifDetailById = useSelector(selectGifDetail);
  
  return (
      <div className='_3lHuNOPnvckvR4CcUUV0gB'>
        <div className='hsiopn'>
          <div className='cFCugU'>

            <div className='btWAEV'>
              {/* Title */}
              <div className='_2z5ML4ex6UJmUfY7XtFQ__'>
                <div className="_2i5vNCJsQy5AsCzf34-UWr">
                  <h1 className="_2UR91XUlAgSU4ZwhD-hyNs _1KuKUOaTOA-MDxUbnxAF0-">{gifDetailById.data?.title}</h1>
                </div>
              </div>
              {/* Image Gif */}
              <div className='_1M8xq1jPOAHRc0OSZxxS8_'>
                <div className='KRS9L9BsuEdhF-ACKiX8x'>
                  <div>
                    <img src={gifDetailById.data?.images.original.url} alt="Coming On My Way GIF by TIFF" />
                  </div>
                </div>
              </div>
            </div>

          </div>
        </div>
      </div>
  )
}

export default GifDetails