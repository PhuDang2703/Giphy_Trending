import React, { useState } from 'react'
import './Search.css'
import { BiSearch } from 'react-icons/bi'
import { useDispatch } from 'react-redux';
import { getGifsBySearch } from '../../redux/slice/gifSlice';

const Search = () => {
    const [search, setSearch] = useState('');
    // console.log('search', search)

    const dispatch = useDispatch();
    const onSubmitSearch = (e) => {
        e.preventDefault();
        console.log('searchOnChange', search)
        try {
            dispatch(getGifsBySearch(search))
        } catch (error) {
            console.log(error)
        }
    }

    return (
        <div className="search__form">
            <form onSubmit={onSubmitSearch}>
                <input type="text" placeholder="Search all the GIFs and Stickers" value={search} onChange={e => setSearch(e.target.value)} />
                <button type='submit'>
                    <BiSearch className='biSearch' size={35} />
                </button>
            </form>
        </div>
    )
}

export default Search