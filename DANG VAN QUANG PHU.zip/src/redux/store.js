import { configureStore, combineReducers } from "@reduxjs/toolkit";
import gifReducer from "./slice/gifSlice"

const rootReducer = combineReducers({
  gif: gifReducer,
})

const store = configureStore({
  reducer: rootReducer,
  //api->getDefault middleware->Customizing the Included Middleware
  middleware: (getDefaultMiddleware) =>
    getDefaultMiddleware({
      //   thunk: {
      //     extraArgument: myCustomApiService,
      //   },
      serializableCheck: false,
    }),
})

export default store;