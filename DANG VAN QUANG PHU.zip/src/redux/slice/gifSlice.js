import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";

const apiKey = 'qnhj5uJlA5asEPIjgkpiuRDoYuVA2xYj';
const numberGif = 50;//max 50 for beta key
const numberGifsSearch = 20;

const apiTrending = `https://api.giphy.com/v1/gifs/trending?api_key=${apiKey}&limit=${numberGif}&offset=0&rating=g&bundle=messaging_non_clips`;

const apiById = (id) => {
    return `https://api.giphy.com/v1/gifs/${id}?api_key=qnhj5uJlA5asEPIjgkpiuRDoYuVA2xYj&rating=g`
}

const apiSearch = (search) => {
    return `https://api.giphy.com/v1/gifs/search?api_key=qnhj5uJlA5asEPIjgkpiuRDoYuVA2xYj&q=${search}&limit=${numberGifsSearch}&offset=0&rating=g&lang=en&bundle=messaging_non_clips`
}

export const getGifs = createAsyncThunk(
    'gif/getGifs',
    async (_, { rejectWithValue }) => {
        try {
            const response = await fetch(apiTrending);
            if (!response.ok) {
                // Nếu yêu cầu không thành công, ném một lỗi
                throw new Error('Network response was not ok');
            }
            const data = await response.json();

            // Trả về dữ liệu thành công
            return data;
        } catch (error) {
            // Trả về lỗi nếu có lỗi trong quá trình gửi yêu cầu hoặc xử lý dữ liệu
            return rejectWithValue(error.message);
        }
    }
);

export const getGifDetailById = createAsyncThunk(
    "gif/getGifDetailById",
    async (id, { rejectWithValue }) => {
        try {
            const response = await fetch(apiById(id));
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            
            const data = await response.json();
            return data;
        } catch (error) {
            rejectWithValue(error);
        }
    }
);

export const getGifsBySearch = createAsyncThunk(
    "gif/getGifsBySearch",
    async (search, { rejectWithValue }) => {
        try {
            const response = await fetch(apiSearch(search));
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }

            const data = await response.json();
            return data;
        } catch (error) {
            rejectWithValue(error);
        }
    }
);

const gifSlice = createSlice({
    name: "gif",
    initialState: {
        gifs: [],
        gifDetailById: [],
        getGifsBySearch: [],
        filteredGifs: [],
        settings: {
            isLoading: false,
            error: false,
            message: "",
        },
    },
    reducers: {},
    extraReducers: {
        [getGifs.fulfilled]: (state, action) => {
            console.log("getGif", action.payload)
            state.gifs = action.payload;
        },
        [getGifDetailById.fulfilled]: (state, action) => {
            state.gifDetailById = action.payload;
            state.settings.isLoading = false;
        },
        [getGifDetailById.pending]: (state, action) => {
            state.settings.isLoading = true;
        },
        [getGifDetailById.rejected]: (state) => {
            state.settings.isLoading = false;
            state.settings.error = true;
        },
        [getGifsBySearch.fulfilled]: (state, action) => {
            console.log('searchAction', action.payload)
            state.getGifsBySearch = action.payload;
            state.settings.isLoading = false;
        },
        [getGifsBySearch.pending]: (state, action) => {
            state.settings.isLoading = true;
        },
        [getGifsBySearch.rejected]: (state) => {
            state.settings.isLoading = false;
            state.settings.error = true;
        },
    },
});

export const { FILTER_BY_SEARCH } = gifSlice.actions
export const selectGif = (state) => state.gif.gifs;
export const selectGifDetail = (state) => state.gif.gifDetailById;
export const selectGifsBySearch = (state) => state.gif.getGifsBySearch;
export const selectLoading = (state) => state.gif.settings;

export default gifSlice.reducer;