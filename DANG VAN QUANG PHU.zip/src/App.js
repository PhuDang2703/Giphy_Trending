import { BrowserRouter, Route, Routes } from "react-router-dom";
import './App.css';
import Header from "./components/header/Header";
import Trending from "./page/trending/Trending";
import TrendingDetails from "./page/trendingDetails/TrendingDetails";

function App() {
  return (
    <div className="container">
      <BrowserRouter>
        <Header />

        <Routes>
          <Route path="/" element={<Trending />} />
          <Route path="/gif-details/:id" element={<TrendingDetails />} />
        </Routes>

      </BrowserRouter>
    </div>
  );
}

export default App;
