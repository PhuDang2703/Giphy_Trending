import { useEffect } from 'react'
import GifItem from '../../components/gif/gifItem/GifItem'
import './Trending.css'
import { useDispatch, useSelector } from 'react-redux'
import { getGifs, selectGif, selectGifsBySearch, selectLoading } from '../../redux/slice/gifSlice'
import { Col, Row } from 'antd';
import Loader from '../../components/loader/Loader'

const Trending = () => {
  const gifs = useSelector(selectGif);
  const {isLoading} = useSelector(selectLoading);
  const gifsSearch = useSelector(selectGifsBySearch);
  console.log('gifsSearch', gifsSearch.data)
  console.log('gifs', gifs.data);

  const dispatch = useDispatch();

  const getCurrentGifs = () => {
    const gifsToRender = gifsSearch.length === 0 ? gifs.data : gifsSearch.data;
    return (
      <Row gutter={{
        xs: 8,
        sm: 16,
        // md: 24,
        // lg: 32,
      }}>
        {
          (
            <>
              {gifsToRender?.map((gif) => {
                return (
                  <Col className="gutter-row" span={6}>
                    <div key={gif.id}>
                      <GifItem {...gif} gif={gif} />
                    </div>
                  </Col>
                )
              })}
            </>
          )
        }

      </Row>
    )
  }

  useEffect(() => {
    dispatch(getGifs());
  }, [dispatch])

  return (
    <div>
      <div className="Header-sc-1qleghs fFkvYt">
        <h4>Trending GIFs</h4>
      </div>
      <div className="Container-sc-1ekfdyy jnvJOY">
        {isLoading ? <Loader/> : (
          <div className='giphy-grid'>
          {getCurrentGifs()}
        </div>
        )}   
      </div>
    </div>

  )
}

export default Trending