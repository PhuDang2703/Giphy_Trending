import { useParams } from 'react-router-dom'
import GifDetails from '../../components/gif/gifDetails/GifDetails'
import './TrendingDetails.css'
import { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { getGifDetailById, selectGifDetail, selectLoading } from '../../redux/slice/gifSlice';
import Loader from '../../components/loader/Loader';

const TrendingDetails = () => {

  const {isLoading} = useSelector(selectLoading);
  const { id } = useParams();
  console.log("id", id);
  const gifDetailById = useSelector(selectGifDetail);
  console.log('gifDetailById', gifDetailById)

  const dispatch = useDispatch();
  useEffect(() => {
    dispatch(getGifDetailById(id));
  }, [dispatch, id]);

  return (
    <>
    {isLoading ? (<Loader/>) : (

    <div className='_2vK2p_vlHej9PMLWlG644r'>
  
      {/* Left page */}
      <div className='_2iyyI26wU2KSCOyckTl0fY'>
        <div>
          <div>
            <div className='cfGKH'>
              <div className='evUOol'>
                
                <div className='EOo4OI8AMJtzGy4Ynpeb8 '>
                  <img className='egeecXcD3ucUqe4ygxn9S' src={gifDetailById.data?.user.avatar_url} alt={ gifDetailById.data?.user.username}/>
                  <h2 className="sbwXHA1t1NpK1k5gv0Bt9">
                    {gifDetailById.data?.user.display_name}
                  </h2>
                  <div className='_3iT_S1Bu6kxI1LHLf1zf3r'>
                    <a href='/' className='_4P63NI68ltZ-kREBhiXwl'>
                      @{gifDetailById.data?.user.username}
                    </a>
                  </div>
                </div>
              
              </div>
              <p className='hZxfCy'>
              {gifDetailById.data?.user.description}
              </p>

              <p className='jlpVpi'>
                Read More
              </p>

              {/* Follow on */}
              <div className='dgNDfP'>
                <div className="eDMrXf">
                  <p className="izPrYj">Follow on:</p>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Make your own virtual Background */}
        <div className='iJXwuZ'>
          <div>
            <div className="fyIALS dTvTRg">Make Your Own Virtual Background</div>
            <img src="	https://giphy.com/static/img/zoomies-small.gif" alt='' className="Image-sc-1hfmjpf eGPVJr" />
            <a href="/" className="hDubuS brXegL">Learn More</a>
          </div>

        </div>
      </div>

      {/* Right page */}
      <GifDetails/>
    </div>
    )}
    </>
  )
}

export default TrendingDetails